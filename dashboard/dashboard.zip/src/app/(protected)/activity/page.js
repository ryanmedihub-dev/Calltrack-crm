'use client';
import { useEffect, useState } from 'react';
import api from '../../../lib/api';
import { SkeletonTable } from '../../../components/Skeleton';

const TYPE_CONFIG = {
  incoming:  { label: 'Incoming Call',  color: '#10B981', bg: '#ECFDF5', icon: '↙' },
  outgoing:  { label: 'Outgoing Call',  color: '#F59E0B', bg: '#FFFBEB', icon: '↗' },
  missed:    { label: 'Missed Call',    color: '#EF4444', bg: '#FEF2F2', icon: '✗' },
  rejected:  { label: 'Rejected Call',  color: '#8B5CF6', bg: '#F5F3FF', icon: '⊘' },
};

function groupByDate(calls) {
  const map = {};
  calls.forEach(call => {
    const date = new Date(call.timestamp).toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
    if (!map[date]) map[date] = [];
    map[date].push(call);
  });
  return Object.entries(map);
}

function formatTime(ts) {
  return new Date(ts).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
}
function formatDur(sec) {
  if (!sec) return '—';
  const m = Math.floor(sec / 60), s = sec % 60;
  return m > 0 ? `${m}m ${s}s` : `${s}s`;
}

export default function ActivityLogPage() {
  const [calls,    setCalls]    = useState([]);
  const [loading,  setLoading]  = useState(true);
  const [page,     setPage]     = useState(1);
  const [total,    setTotal]    = useState(0);
  const [typeFilter, setTypeFilter] = useState('all');
  const [empFilter,  setEmpFilter]  = useState('all');
  const [employees,  setEmployees]  = useState([]);
  const LIMIT = 50;

  const load = async (p = 1) => {
    setLoading(true);
    try {
      const params = { page: p, limit: LIMIT };
      if (typeFilter !== 'all') params.callType = typeFilter;
      if (empFilter  !== 'all') params.employeeId = empFilter;
      const res = await api.get('/api/calls', { params });
      const data = res.data.data;
      setCalls(data?.calls || data || []);
      setTotal(data?.total || 0);
      setPage(p);
    } catch {}
    setLoading(false);
  };

  useEffect(() => {
    api.get('/api/employees').then(r => setEmployees(r.data.data || [])).catch(() => {});
  }, []);

  useEffect(() => { load(1); }, [typeFilter, empFilter]);

  const grouped = groupByDate(calls);
  const pages   = Math.ceil(total / LIMIT);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-xl font-bold text-textPrimary">Activity Log</h2>
        <p className="text-textMuted text-sm mt-0.5">Timeline of all call activity across the team</p>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3 items-center">
        <select value={typeFilter} onChange={e => setTypeFilter(e.target.value)}
          className="border border-border rounded-xl px-3 py-2 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary">
          <option value="all">All Types</option>
          <option value="incoming">Incoming</option>
          <option value="outgoing">Outgoing</option>
          <option value="missed">Missed</option>
          <option value="rejected">Rejected</option>
        </select>

        <select value={empFilter} onChange={e => setEmpFilter(e.target.value)}
          className="border border-border rounded-xl px-3 py-2 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary">
          <option value="all">All Employees</option>
          {employees.map(e => <option key={e._id} value={e._id}>{e.name}</option>)}
        </select>

        <p className="text-xs text-textMuted ml-auto">{total.toLocaleString()} total records</p>
      </div>

      {/* Timeline */}
      {loading ? (
        <SkeletonTable rows={8} />
      ) : calls.length === 0 ? (
        <div className="bg-white border border-border rounded-2xl p-16 text-center shadow-card">
          <p className="text-textMuted text-sm">No activity found for selected filters.</p>
        </div>
      ) : (
        <div className="space-y-6">
          {grouped.map(([date, dayCalls]) => (
            <div key={date}>
              {/* Date header */}
              <div className="flex items-center gap-3 mb-3">
                <div className="h-px flex-1 bg-border" />
                <span className="text-xs font-bold text-textMuted bg-bg border border-border rounded-full px-3 py-1 flex-shrink-0">
                  {date}
                </span>
                <span className="text-xs text-textMuted flex-shrink-0">{dayCalls.length} calls</span>
                <div className="h-px flex-1 bg-border" />
              </div>

              {/* Calls for this date */}
              <div className="bg-white border border-border rounded-2xl shadow-card overflow-hidden">
                <div className="divide-y divide-border">
                  {dayCalls.map((call, i) => {
                    const cfg = TYPE_CONFIG[call.callType] || TYPE_CONFIG.outgoing;
                    return (
                      <div key={call._id || i} className="flex items-center gap-4 px-5 py-3.5 hover:bg-bg transition-colors">
                        {/* Time */}
                        <span className="text-xs text-textMuted font-mono w-14 flex-shrink-0 tabular-nums">
                          {formatTime(call.timestamp)}
                        </span>

                        {/* Type badge */}
                        <div className="w-8 h-8 rounded-xl flex items-center justify-center text-sm font-bold flex-shrink-0"
                          style={{ background: cfg.bg, color: cfg.color }}>
                          {cfg.icon}
                        </div>

                        {/* Contact */}
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-textPrimary truncate">
                            {call.contactName || call.contactNumber}
                          </p>
                          {call.contactName && (
                            <p className="text-xs text-textMuted font-mono">{call.contactNumber}</p>
                          )}
                        </div>

                        {/* Employee */}
                        <span className="text-xs text-textSecondary hidden sm:block flex-shrink-0 max-w-[120px] truncate">
                          {call.employeeName}
                        </span>

                        {/* Duration */}
                        <span className="text-xs font-semibold text-textSecondary flex-shrink-0 w-14 text-right tabular-nums">
                          {formatDur(call.duration)}
                        </span>

                        {/* Type label */}
                        <span className="hidden md:inline-block text-[10px] font-bold px-2 py-0.5 rounded-full flex-shrink-0"
                          style={{ color: cfg.color, background: cfg.bg }}>
                          {cfg.label}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Pagination */}
      {pages > 1 && (
        <div className="flex items-center justify-center gap-2 pt-2">
          <button disabled={page === 1} onClick={() => load(page - 1)}
            className="px-4 py-2 rounded-xl border border-border text-sm font-medium text-textSecondary hover:border-primary hover:text-primary disabled:opacity-40 disabled:cursor-not-allowed transition-colors">
            ← Prev
          </button>
          <span className="text-sm text-textMuted px-2">Page {page} of {pages}</span>
          <button disabled={page === pages} onClick={() => load(page + 1)}
            className="px-4 py-2 rounded-xl border border-border text-sm font-medium text-textSecondary hover:border-primary hover:text-primary disabled:opacity-40 disabled:cursor-not-allowed transition-colors">
            Next →
          </button>
        </div>
      )}
    </div>
  );
}
