'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import api from '../../../../lib/api';
import { triggerLocalExport } from '../../../../lib/downloads';
import { fmtDate } from '../../../../lib/timezone';
import {
  DataTable, StatCard, EmptyState, Field,
  DownloadIco, SearchIco, UsersIco,
} from '../../../../components/report-shared';

const ROLE_COLORS = {
  admin: { color: '#7C3AED', bg: '#F5F3FF' },
  manager: { color: '#2563EB', bg: '#EFF6FF' },
  agent: { color: '#16A34A', bg: '#F0FDF4' },
  supervisor: { color: '#D97706', bg: '#FFFBEB' },
};

const fmt = fmtDate;

function RoleBadge({ role }) {
  const rc = ROLE_COLORS[role] || { color: '#64748B', bg: '#F1F5F9' };
  return (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-xs font-medium capitalize" style={{ color: rc.color, background: rc.bg }}>
      <span className="w-1.5 h-1.5 rounded-full" style={{ background: rc.color }} />
      {role}
    </span>
  );
}

function StatusBadge({ status }) {
  const active = status === 'active';
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-xs font-medium capitalize ${active ? 'text-emerald-600 bg-emerald-50' : 'text-red-600 bg-red-50'}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${active ? 'bg-emerald-500' : 'bg-red-500'}`} />
      {status}
    </span>
  );
}

export default function UsersReportPage() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [role, setRole] = useState('');

  useEffect(() => {
    api.get('/api/employees').then((r) => { setUsers(r.data?.data || []); }).catch(() => {}).finally(() => setLoading(false));
  }, []);

  const filtered = users.filter((u) => {
    const ms = !search || u.name?.toLowerCase().includes(search.toLowerCase()) || u.email?.toLowerCase().includes(search.toLowerCase()) || u.phone?.includes(search);
    const mr = !role || (u.role || 'agent') === role;
    return ms && mr;
  });

  const roleCounts = users.reduce((acc, u) => { const r = u.role || 'agent'; acc[r] = (acc[r] || 0) + 1; return acc; }, {});
  const roles = [...new Set(users.map((u) => u.role || 'agent'))];

  const exportCSV = () => {
    const rows = [['Name', 'Email', 'Phone', 'Role', 'Status', 'Joined'], ...filtered.map((u) => [u.name || '', u.email || '', u.phone || '', u.role || 'agent', u.status || 'active', fmt(u.createdAt)])];
    const csv = rows.map((r) => r.join(',')).join('\n');
    triggerLocalExport({ label: 'Users Report', filename: 'users-report.csv', csv });
  };

  const rows = filtered.map((u, i) => ({ ...u, id: u._id || i }));

  return (
    <div className="min-h-screen">
      <div className="space-y-5">

        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <p className="text-xs text-gray-400 flex items-center gap-1.5">
              Reports <span className="text-gray-300">/</span> <span className="text-gray-500">Users Report</span>
            </p>
            <h1 className="text-xl font-bold text-gray-900 mt-0.5">Users Report</h1>
          </div>
          <div className="flex items-center gap-2">
            <Link href="/users" className="flex items-center gap-2 px-3.5 py-2 border border-gray-200 bg-white text-gray-600 rounded-lg hover:bg-gray-50 transition-colors text-sm font-medium">
              Manage Users
            </Link>
            <button onClick={exportCSV} className="flex items-center gap-2 px-3.5 py-2 bg-gray-900 text-white rounded-lg hover:bg-gray-800 transition-colors text-sm font-medium shadow-sm">
              <DownloadIco /> Export
            </button>
          </div>
        </div>

        {/* Role breakdown */}
        {roles.length === 0 && !loading ? (
          <div className="bg-white rounded-xl border border-gray-200 p-5">
            <EmptyState title="No users data" hint="Add employees to see role breakdown here." />
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {(loading ? Array.from({ length: 4 }) : roles).map((r, i) => {
              const rc = ROLE_COLORS[r] || { color: '#64748B', bg: '#F1F5F9' };
              return (
                <StatCard
                  key={r || i}
                  loading={loading}
                  label={r ? `${r.charAt(0).toUpperCase()}${r.slice(1)}s` : ''}
                  value={(roleCounts[r] || 0).toLocaleString()}
                  color={rc.color}
                  icon={<UsersIco s={16} />}
                />
              );
            })}
          </div>
        )}

        {/* Filters */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <Field label="Search">
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"><SearchIco /></span>
                <input className="input pl-9" placeholder="Search by name, email, or phone…" value={search} onChange={(e) => setSearch(e.target.value)} />
              </div>
            </Field>
            <Field label="Role">
              <select className="input" value={role} onChange={(e) => setRole(e.target.value)}>
                <option value="">All Roles</option>
                {roles.map((r) => <option key={r} value={r}>{r.charAt(0).toUpperCase() + r.slice(1)}</option>)}
              </select>
            </Field>
          </div>
        </div>

        {/* Table */}
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <h3 className="text-sm font-bold text-gray-900 mb-1">{filtered.length} users</h3>
          <p className="text-xs text-gray-400 mb-3">All system users with roles, contact details, and status</p>
          <DataTable
            loading={loading}
            searchable={false}
            emptyTitle="No users found"
            columns={[
              { key: 'name', label: 'User', render: (u) => (
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg flex items-center justify-center text-white text-[11px] font-bold shrink-0" style={{ background: 'linear-gradient(135deg,#2563EB,#60A5FA)' }}>
                    {(u.name || '?').slice(0, 2).toUpperCase()}
                  </div>
                  <span className="font-semibold text-xs text-gray-900">{u.name || 'Unknown'}</span>
                </div>
              ) },
              { key: 'email', label: 'Email', render: (u) => u.email || '—' },
              { key: 'phone', label: 'Phone', render: (u) => <span className="font-mono text-xs">{u.phone || '—'}</span> },
              { key: 'role', label: 'Role', searchable: false, render: (u) => <RoleBadge role={u.role || 'agent'} /> },
              { key: 'status', label: 'Status', searchable: false, render: (u) => <StatusBadge status={u.workingStatus || u.status || 'active'} /> },
              { key: 'createdAt', label: 'Joined', searchable: false, render: (u) => fmt(u.createdAt) },
            ]}
            rows={rows}
          />
        </div>
      </div>

      <style jsx global>{`
        .input {
          width: 100%;
          padding: 0.5rem 0.75rem;
          border-radius: 0.5rem;
          border: 1px solid #E5E7EB;
          font-size: 0.8125rem;
          outline: none;
          background: white;
          transition: border-color 0.15s;
        }
        .input:focus { border-color: #3B82F6; box-shadow: 0 0 0 3px rgba(59,130,246,0.1); }
      `}</style>
    </div>
  );
}
