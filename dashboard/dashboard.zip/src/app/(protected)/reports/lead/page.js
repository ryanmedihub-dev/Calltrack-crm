'use client';
import { useEffect, useState, useCallback } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import api from '../../../../lib/api';
import { triggerLocalExport } from '../../../../lib/downloads';
import {
  DataTable, StatCard, ChartTip,
  DownloadIco, UsersIco, CheckIco, GaugeIco, XIco,
} from '../../../../components/report-shared';

const STATUSES = [
  { key: 'new', label: 'New', color: '#2563EB', bg: '#EFF6FF' },
  { key: 'contacted', label: 'Contacted', color: '#D97706', bg: '#FFFBEB' },
  { key: 'qualified', label: 'Qualified', color: '#7C3AED', bg: '#F5F3FF' },
  { key: 'interested', label: 'Interested', color: '#0D9488', bg: '#F0FDFA' },
  { key: 'converted', label: 'Converted', color: '#16A34A', bg: '#F0FDF4' },
  { key: 'lost', label: 'Lost', color: '#DC2626', bg: '#FFF1F2' },
];

const PERIODS = [{ k: 'today', l: 'Today' }, { k: 'week', l: 'This Week' }, { k: 'month', l: 'This Month' }, { k: 'all', l: 'All Time' }];

function StatusBadge({ status }) {
  const s = STATUSES.find((x) => x.key === status) || STATUSES[0];
  return (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-xs font-medium" style={{ color: s.color, background: s.bg }}>
      <span className="w-1.5 h-1.5 rounded-full" style={{ background: s.color }} />
      {s.label}
    </span>
  );
}

export default function LeadReportPage() {
  const [period, setPeriod] = useState('month');
  const [counts, setCounts] = useState({});
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const results = await Promise.all(
        STATUSES.map((s) =>
          api.get('/api/leads', { params: { status: s.key, limit: 1, period } })
            .then((r) => ({ key: s.key, count: r.data?.data?.total || 0 }))
            .catch(() => ({ key: s.key, count: 0 }))
        )
      );
      const map = {};
      results.forEach((r) => { map[r.key] = r.count; });
      setCounts(map);
    } catch {}
    setLoading(false);
  }, [period]);

  useEffect(() => { load(); }, [load]);

  const total = Object.values(counts).reduce((s, n) => s + n, 0);
  const convRate = total > 0 ? ((counts.converted || 0) / total * 100).toFixed(1) : '0.0';
  const lossRate = total > 0 ? ((counts.lost || 0) / total * 100).toFixed(1) : '0.0';
  const barData = STATUSES.map((s) => ({ name: s.label, count: counts[s.key] || 0 }));
  const pieData = STATUSES.map((s) => ({ name: s.label, value: counts[s.key] || 0, color: s.color })).filter((d) => d.value > 0);

  const exportCSV = () => {
    const rows = [['Status', 'Count', 'Percentage'], ...STATUSES.map((s) => [s.label, counts[s.key] || 0, total > 0 ? ((counts[s.key] || 0) / total * 100).toFixed(1) + '%' : '0%'])];
    const csv = rows.map((r) => r.join(',')).join('\n');
    triggerLocalExport({ label: 'Lead Report', filename: 'lead-report.csv', csv });
  };

  const summaryRows = STATUSES.map((s) => {
    const count = counts[s.key] || 0;
    const pct = total > 0 ? Math.round((count / total) * 100) : 0;
    return { id: s.key, status: s.key, count, pct };
  });
  const summaryFooter = { status: 'Total', count: total, pct: '100%' };

  return (
    <div className="min-h-screen">
      <div className="space-y-5">

        {/* ── Header ── */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <p className="text-xs text-gray-400 flex items-center gap-1.5">
              Reports <span className="text-gray-300">/</span> <span className="text-gray-500">Lead Report</span>
            </p>
            <h1 className="text-xl font-bold text-gray-900 mt-0.5">Lead Report</h1>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex gap-0.5 bg-gray-100 rounded-lg p-1">
              {PERIODS.map((p) => (
                <button
                  key={p.k}
                  onClick={() => setPeriod(p.k)}
                  className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-colors ${period === p.k ? 'bg-white shadow-sm text-gray-900' : 'text-gray-500 hover:text-gray-700'}`}
                >
                  {p.l}
                </button>
              ))}
            </div>
            <button onClick={exportCSV} className="flex items-center gap-2 px-3.5 py-2 bg-gray-900 text-white rounded-lg hover:bg-gray-800 transition-colors text-sm font-medium shadow-sm">
              <DownloadIco /> Export
            </button>
          </div>
        </div>

        {/* ── KPI tiles ── */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <StatCard loading={loading} label="Total Leads" value={total.toLocaleString()} color="#2563EB" icon={<UsersIco />} />
          <StatCard loading={loading} label="Converted" value={(counts.converted || 0).toLocaleString()} color="#16A34A" icon={<CheckIco />} />
          <StatCard loading={loading} label="Conversion Rate" value={`${convRate}%`} color="#0D9488" icon={<GaugeIco />} />
          <StatCard loading={loading} label="Loss Rate" value={`${lossRate}%`} color="#DC2626" icon={<XIco />} />
        </div>

        {/* ── Charts ── */}
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
          <div className="xl:col-span-2 bg-white rounded-xl border border-gray-200 p-5">
            <h3 className="text-sm font-bold text-gray-900 mb-1">Lead Status Breakdown</h3>
            <p className="text-xs text-gray-400 mb-4">Number of leads in each pipeline stage</p>
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={barData} barCategoryGap="35%">
                <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" vertical={false} />
                <XAxis dataKey="name" tick={{ fill: '#94A3B8', fontSize: 10 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: '#94A3B8', fontSize: 10 }} axisLine={false} tickLine={false} width={28} allowDecimals={false} />
                <Tooltip content={<ChartTip />} />
                <Bar dataKey="count" name="Leads" radius={[5, 5, 0, 0]}>
                  {barData.map((_, i) => <Cell key={i} fill={STATUSES[i]?.color || '#2563EB'} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="bg-white rounded-xl border border-gray-200 p-5">
            <h3 className="text-sm font-bold text-gray-900 mb-1">Distribution</h3>
            <p className="text-xs text-gray-400 mb-3">Share of total leads</p>
            {pieData.length === 0 ? (
              <div className="flex items-center justify-center h-40"><p className="text-sm text-gray-400">No data</p></div>
            ) : (
              <>
                <ResponsiveContainer width="100%" height={150}>
                  <PieChart>
                    <Pie data={pieData} cx="50%" cy="50%" innerRadius={38} outerRadius={60} paddingAngle={3} dataKey="value" strokeWidth={0}>
                      {pieData.map((e, i) => <Cell key={i} fill={e.color} />)}
                    </Pie>
                    <Tooltip content={<ChartTip />} />
                  </PieChart>
                </ResponsiveContainer>
                <div className="space-y-1.5 mt-1">
                  {pieData.map((d) => (
                    <div key={d.name} className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full" style={{ background: d.color }} /><span className="text-gray-500">{d.name}</span></div>
                      <span className="font-bold text-gray-900">{d.value}</span>
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>
        </div>

        {/* ── Status summary table ── */}
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <h3 className="text-sm font-bold text-gray-900 mb-1">Status Summary Table</h3>
          <p className="text-xs text-gray-400 mb-3">Lead counts and share by pipeline status</p>
          <DataTable
            rows={summaryRows}
            loading={loading}
            searchable={false}
            pageSize={summaryRows.length}
            footer={summaryFooter}
            columns={[
              { key: 'status', label: 'Status', render: (r) => <StatusBadge status={r.status} /> },
              { key: 'count', label: 'Count', align: 'right', render: (r) => <span className="font-bold" style={{ color: (STATUSES.find((s) => s.key === r.status) || {}).color }}>{r.count}</span> },
              { key: 'pct', label: 'Percentage', align: 'right', render: (r) => `${r.pct}%` },
              {
                key: 'bar', label: 'Bar', sortable: false, render: (r) => (
                  <div className="w-32 h-2 rounded-full overflow-hidden bg-gray-100">
                    <div className="h-full rounded-full transition-all duration-700" style={{ width: `${r.pct}%`, background: (STATUSES.find((s) => s.key === r.status) || {}).color }} />
                  </div>
                ),
              },
            ]}
          />
        </div>
      </div>
    </div>
  );
}
