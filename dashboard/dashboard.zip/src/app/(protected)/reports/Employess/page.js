'use client';
import { useEffect, useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import api from '../../../../lib/api';
import { triggerLocalExport } from '../../../../lib/downloads';
import {
  DataTable, StatCard, ChartTip, EmptyState,
  DownloadIco, UsersIco,
} from '../../../../components/report-shared';

const PERIODS = [{ k: 'today', l: 'Today' }, { k: 'week', l: 'This Week' }, { k: 'month', l: 'This Month' }];
const MEDALS = ['🥇', '🥈', '🥉'];

export default function EmployeesReportPage() {
  const [period, setPeriod] = useState('week');
  const [employees, setEmployees] = useState([]);
  const [dialers, setDialers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      setLoading(true);
      try {
        const [empRes, statsRes] = await Promise.allSettled([
          api.get('/api/employees'),
          api.get('/api/calls/stats'),
        ]);
        const emps = empRes.status === 'fulfilled' ? empRes.value.data?.data || [] : [];
        const stats = statsRes.status === 'fulfilled' ? statsRes.value.data?.data : null;
        setEmployees(emps);
        const key = period === 'today' ? 'today' : period === 'week' ? 'thisWeek' : 'thisMonth';
        setDialers(stats?.[key]?.topDialers || stats?.today?.topDialers || []);
      } catch {}
      setLoading(false);
    })();
  }, [period]);

  const total = dialers.reduce((s, d) => s + d.count, 0) || 1;
  const maxCalls = dialers[0]?.count || 1;
  const barData = dialers.slice(0, 12).map((d) => ({ name: (d.name || '').split(' ')[0], calls: d.count }));

  const exportCSV = () => {
    const rows = [['Rank', 'Name', 'Calls', 'Share %'], ...dialers.map((d, i) => [i + 1, d.name, d.count, Math.round((d.count / total) * 100)])];
    const csv = rows.map((r) => r.join(',')).join('\n');
    triggerLocalExport({ label: 'Employees Report', filename: 'employees-report.csv', csv });
  };

  const rankingRows = dialers.map((d, i) => ({
    ...d,
    id: d.employeeId || i,
    rank: i + 1,
    share: Math.round((d.count / total) * 100),
    role: employees.find((e) => e._id === d.employeeId)?.role || 'Agent',
  }));

  return (
    <div className="min-h-screen">
      <div className="space-y-5">

        {/* ── Header ── */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <p className="text-xs text-gray-400 flex items-center gap-1.5">
              Reports <span className="text-gray-300">/</span> <span className="text-gray-500">Employees Report</span>
            </p>
            <h1 className="text-xl font-bold text-gray-900 mt-0.5">Employees Report</h1>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex gap-0.5 bg-gray-100 rounded-lg p-1">
              {PERIODS.map((p) => (
                <button
                  key={p.k}
                  onClick={() => setPeriod(p.k)}
                  className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-colors ${period === p.k ? 'bg-white shadow-sm text-gray-900' : 'text-gray-500 hover:text-gray-700'}`}
                >
                  {p.l}
                </button>
              ))}
            </div>
            <button onClick={exportCSV} className="flex items-center gap-2 px-3.5 py-2 bg-gray-900 text-white rounded-lg hover:bg-gray-800 transition-colors text-sm font-medium shadow-sm">
              <DownloadIco /> Export
            </button>
          </div>
        </div>

        {/* ── KPI tiles ── */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <StatCard loading={loading} label="Total Employees" value={employees.length.toLocaleString()} color="#2563EB" icon={<UsersIco />} />
          <StatCard loading={loading} label="Active Callers" value={dialers.filter((d) => d.count > 0).length.toLocaleString()} color="#16A34A" icon={<UsersIco />} />
          <StatCard loading={loading} label="Total Calls" value={dialers.reduce((s, d) => s + d.count, 0).toLocaleString()} color="#D97706" icon={<UsersIco />} />
          <StatCard loading={loading} label="Avg per Caller" value={(dialers.length ? Math.round(dialers.reduce((s, d) => s + d.count, 0) / dialers.length) : 0).toLocaleString()} color="#7C3AED" icon={<UsersIco />} />
        </div>

        {/* ── Chart ── */}
        {!loading && barData.length > 0 && (
          <div className="bg-white rounded-xl border border-gray-200 p-5">
            <h3 className="text-sm font-bold text-gray-900 mb-1">Top Employees by Calls</h3>
            <p className="text-xs text-gray-400 mb-4">Call volume leaders for the selected period</p>
            <ResponsiveContainer width="100%" height={Math.max(200, barData.length * 30)}>
              <BarChart data={barData} barSize={22} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" horizontal={false} />
                <XAxis type="number" tick={{ fontSize: 10, fill: '#94A3B8' }} tickLine={false} axisLine={false} allowDecimals={false} />
                <YAxis type="category" dataKey="name" tick={{ fontSize: 11, fill: '#475569', fontWeight: 600 }} tickLine={false} axisLine={false} width={72} />
                <Tooltip content={<ChartTip />} />
                <Bar dataKey="calls" name="Calls" fill="#2563EB" radius={[0, 5, 5, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}

        {/* ── Full table ── */}
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <h3 className="text-sm font-bold text-gray-900 mb-1">Full Employee Rankings</h3>
          <p className="text-xs text-gray-400 mb-3">Every employee ranked by call volume</p>
          {!loading && rankingRows.length === 0 ? (
            <EmptyState title="No data for this period" hint="Try a different period." />
          ) : (
            <DataTable
              rows={rankingRows}
              loading={loading}
              pageSize={rankingRows.length || 10}
              columns={[
                {
                  key: 'rank', label: 'Rank', render: (r) => (
                    r.rank <= 3 ? <span className="text-lg">{MEDALS[r.rank - 1]}</span> : <span className="font-bold text-xs text-gray-400">#{r.rank}</span>
                  ),
                },
                {
                  key: 'name', label: 'Employee', render: (r) => (
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-lg flex items-center justify-center text-white text-[10px] font-bold shrink-0" style={{ background: 'linear-gradient(135deg,#2563EB,#60A5FA)' }}>
                        {(r.name || '?').slice(0, 2).toUpperCase()}
                      </div>
                      <div>
                        <p className="font-semibold text-xs text-gray-900">{r.name || 'Unknown'}</p>
                        <p className="text-[10px] capitalize text-gray-400">{r.role}</p>
                      </div>
                    </div>
                  ),
                },
                { key: 'count', label: 'Calls', align: 'right', searchable: false, render: (r) => <span className="font-bold text-blue-600">{r.count}</span> },
                {
                  key: 'share', label: 'Share', sortable: false, searchable: false, render: (r) => (
                    <div className="flex items-center gap-2">
                      <div className="h-1.5 w-20 rounded-full overflow-hidden bg-gray-200">
                        <div className="h-full rounded-full bg-blue-600" style={{ width: `${(r.count / maxCalls) * 100}%` }} />
                      </div>
                      <span className="text-[10px] tabular-nums text-gray-400">{r.share}%</span>
                    </div>
                  ),
                },
                {
                  key: 'status', label: 'Status', sortable: false, searchable: false, render: () => (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-xs font-medium text-emerald-700 bg-emerald-50">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" /> Active
                    </span>
                  ),
                },
              ]}
            />
          )}
        </div>
      </div>
    </div>
  );
}
