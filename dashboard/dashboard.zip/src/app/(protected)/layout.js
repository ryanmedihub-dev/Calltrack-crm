'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Cookies from 'js-cookie';
import Sidebar from '../../components/Sidebar';
import TopBar from '../../components/TopBar';
import { isAuthenticated } from '../../lib/auth';
import api from '../../lib/api';

export default function ProtectedLayout({ children }) {
  const router = useRouter();
  const [ready, setReady] = useState(false);
  const [user, setUser] = useState(null);
  const [collapsed, setCollapsed] = useState(false);

  useEffect(() => {
    if (!isAuthenticated()) {
      router.push('/login');
      return;
    }
    const saved = localStorage.getItem('sidebarCollapsed');
    if (saved === 'true') setCollapsed(true);

    api.get('/api/auth/me')
      .then(res => setUser(res.data.data))
      .catch(() => {});

    setReady(true);
  }, [router]);

  const toggleSidebar = () => {
    setCollapsed(prev => {
      const next = !prev;
      localStorage.setItem('sidebarCollapsed', String(next));
      return next;
    });
  };

  const handleLogout = () => {
    Cookies.remove('token');
    router.push('/login');
  };

  if (!ready) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-bg">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-blue-400 flex items-center justify-center text-white font-bold shadow animate-pulse select-none">
            CT
          </div>
          <p className="text-textMuted text-sm">Loading…</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-bg">
      <Sidebar collapsed={collapsed} user={user} onLogout={handleLogout} />
      <div className={`flex-1 transition-[margin] duration-300 ease-in-out ${collapsed ? 'ml-[68px]' : 'ml-60'}`}>
        <TopBar collapsed={collapsed} onToggle={toggleSidebar} user={user} />
        <main className="pt-16 min-h-screen">
          <div className="p-6">{children}</div>
        </main>
      </div>
    </div>
  );
}
