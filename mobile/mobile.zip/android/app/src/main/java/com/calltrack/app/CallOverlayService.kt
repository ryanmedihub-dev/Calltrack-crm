package com.calltrack.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder

class CallOverlayService : Service() {

    companion object {
        const val CHANNEL_ID = "calltrack_overlay"
        const val NOTIF_ID   = 9001
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        val notif = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("CallTrack")
                .setContentText("Logging call…")
                .setSmallIcon(android.R.drawable.ic_menu_call)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("CallTrack")
                .setContentText("Logging call…")
                .setSmallIcon(android.R.drawable.ic_menu_call)
                .build()
        }
        startForeground(NOTIF_ID, notif)

        // Launch the transparent overlay activity — allowed from a ForegroundService
        val overlayIntent = Intent(this, CallOverlayActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            intent?.extras?.let { putExtras(it) }
        }
        try { startActivity(overlayIntent) } catch (_: Exception) {}

        stopSelf()
        return START_NOT_STICKY
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val mgr = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            if (mgr.getNotificationChannel(CHANNEL_ID) == null) {
                mgr.createNotificationChannel(
                    NotificationChannel(CHANNEL_ID, "Call Overlay", NotificationManager.IMPORTANCE_LOW)
                )
            }
        }
    }
}
