package com.calltrack.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.WindowManager

class CallOverlayActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Show over lock screen and wake display
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON   or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            )
        }

        // Re-write SharedPrefs so App.js can read them even if it cleared them early
        val number    = intent.getStringExtra("number")    ?: ""
        val name      = intent.getStringExtra("name")      ?: ""
        val callType  = intent.getStringExtra("callType")  ?: ""
        val duration  = intent.getIntExtra("duration", 0)
        val timestamp = intent.getStringExtra("timestamp") ?: ""

        getSharedPreferences("CallTrackPrefs", Context.MODE_PRIVATE).edit()
            .putString ("pending_number",    number)
            .putString ("pending_name",      name)
            .putString ("pending_type",      callType)
            .putInt    ("pending_duration",  duration)
            .putString ("pending_timestamp", timestamp)
            .putBoolean("has_pending",       true)
            .apply()

        // Bring the main app to foreground — it will read SharedPrefs and open AfterCallModal
        val main = Intent(this, MainActivity::class.java).apply {
            addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK        or
                Intent.FLAG_ACTIVITY_SINGLE_TOP      or
                Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
            )
            putExtra("from_call_end", true)
        }
        startActivity(main)
        finish()
    }
}
