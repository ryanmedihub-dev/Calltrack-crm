package com.calltrack.app

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod

class CallLogModule(private val reactContext: ReactApplicationContext) :
    ReactContextBaseJavaModule(reactContext) {

    init { PhoneStateReceiver.reactContext = reactContext }

    override fun getName() = "CallLogModule"

    @ReactMethod
    fun checkPermissions(promise: Promise) {
        val phone   = ContextCompat.checkSelfPermission(reactContext, android.Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED
        val callLog = ContextCompat.checkSelfPermission(reactContext, android.Manifest.permission.READ_CALL_LOG)   == PackageManager.PERMISSION_GRANTED
        promise.resolve(phone && callLog)
    }

    @ReactMethod
    fun setTrackedSim(subscriptionId: Int) {
        PhoneStateReceiver.trackedSubId = subscriptionId
    }

    /** Called from JS on every app foreground to pick up any call that happened while closed */
    @ReactMethod
    fun getPendingCall(promise: Promise) {
        try {
            val prefs = reactContext.getSharedPreferences("CallTrackPrefs", Context.MODE_PRIVATE)
            if (!prefs.getBoolean("has_pending", false)) {
                promise.resolve(null)
                return
            }
            val map = Arguments.createMap().apply {
                putString("contactNumber", prefs.getString("pending_number",    "") ?: "")
                putString("contactName",   prefs.getString("pending_name",      "") ?: "")
                putString("callType",      prefs.getString("pending_type",      "") ?: "")
                putInt   ("duration",      prefs.getInt   ("pending_duration",  0))
                putString("timestamp",     prefs.getString("pending_timestamp", "") ?: "")
            }
            // Clear so we don't show the same call twice
            prefs.edit().putBoolean("has_pending", false).apply()
            promise.resolve(map)
        } catch (e: Exception) {
            promise.resolve(null)
        }
    }

    /** Returns true if SYSTEM_ALERT_WINDOW is granted (needed for overlay popup) */
    @ReactMethod
    fun checkOverlayPermission(promise: Promise) {
        val granted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(reactContext)
        } else {
            true
        }
        promise.resolve(granted)
    }

    /** Opens the "Display over other apps" settings page for this app */
    @ReactMethod
    fun openOverlaySettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${reactContext.packageName}")
            ).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
            try { reactContext.startActivity(intent) } catch (_: Exception) {}
        }
    }

    @ReactMethod fun addListener(eventName: String) {}
    @ReactMethod fun removeListeners(count: Int) {}
}
